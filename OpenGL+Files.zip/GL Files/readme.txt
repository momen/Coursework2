1. Inside the folder you should have:

glut.dll

glut32.dll

glut.h

glut.lib

glut32.lib

2. Copy your glut.h to:

<drive>:\<VC++ path>\include\GL\glut.h

*** put the drive where you installed VC++ instead of the <drive> ***

*** put the directory where you installed VC++ instead of the <VC++ path>

3. Copy your glut.lib and glut32.lib to:

<drive>:\<VC++ path>\lib\glut.lib

<drive>:\<VC++ path>\lib\glut32.lib

*** put the drive where you installed VC++ instead of the <drive> ***

*** put the directory where you installed VC++ instead of the <VC++ path>